import SwiftUI

@main
struct SynthesizerLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


